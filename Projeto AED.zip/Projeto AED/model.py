Datas = ["27/07/2022", "12/08/2022", "29/09/2022", "10/01/2023", "13/02/2023"]
Dias = ["10", "12", "13", "27", "29"]
Mes = ["01", "02", "07", "08", "09"]
ano = ["2022", "2023"]




filas = ["A", "B" ,"C", "D", "E", "F", "G", "H", "I", "J", "K"]
numero_lugar = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14"]
numero_nao_lugarFA = ["3", "4", "5", "10", "11", "12", "13"]
numero_VIP = ["6", "7", "8", "9"]
filas_especiais = ["A", "F"]


numero_lugaresK = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14"]
numero_lugaresJ = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14"]
numero_lugaresI = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14"]
numero_lugaresH = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14"]
numero_lugaresG = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14"]
numero_lugaresF = ["1", "2", "         ", "VIP6", "VIP7", "VIP8", "VIP9", "          ", "14"]
numero_lugaresE = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14"]
numero_lugaresD = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14"]
numero_lugaresC = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14"]
numero_lugaresB = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14"]
numero_lugaresA = ["1", "2", "          ", "VIP6", "VIP7", "VIP8", "VIP9", "         ", "14"]
Palco =           ["                                  PALCO                                "]


Lugares_VIP_Reservado27 = []
Lugares_VIP_Reservado12 = []
Lugares_VIP_Reservado29 = []
Lugares_VIP_Reservado10 = []
Lugares_VIP_Reservado13 = []

Lugares_reservados = []
Lugares_reservados27 = []
Lugares_reservados12 = []
Lugares_reservados29 = []
Lugares_reservados10 = []
Lugares_reservados13 = []


total_lugares = 132
total_lugares_vip = 8

Valor_bilheteira = ["Normal = 4,00€ total 528€",  "VIP = 12,00€ total 96€"]

