import model


def valido_letra (letra):
    if letra in model.filas:
        return True


def valido_numero(letra, numero):
    if int(numero) < 0:
        return False

    elif letra in model.filas_especiais and numero in model.numero_nao_lugarFA:
        return False

    elif numero in model.numero_lugar:
        return True

    else:
        if int(numero) > 14:
            return False 


def Validar_data(data):
    if data in model.Datas == True:
        return True


def verificar_lugares_reservados(letra, numero, data):
    lugares = letra + numero + data
    if lugares in model.Lugares_reservados:
        return False
    else:
        return True


def reservar_lugares(letra, numero, data):
    lugares = letra + numero + data
    if verificar_lugares_reservados(letra, numero, data) == True:
        model.data_reservadaa.append(data)
        model.Lugares_reservados.append(lugares)


def eliminar_lugar_reservado(letra, numero, data):
    lugares = letra + numero + data
    if verificar_lugares_reservados(letra, numero, data) == False:
        model.data_reservada.remove(data)
        model.Lugares_reservados.remove(lugares)
        

def contar_valor(data):
    if data in model.data_reservada:
        nº = len(data in model.data_reservada)
        

    

        
    
    


    

      
        
