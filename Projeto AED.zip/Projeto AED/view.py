import model
import controller

print("\n Seja Bem-vindo ao teatro. \n")
print(f"As datas dos espetáculos são: {model.Datas}\n")
print("\n Escolha um lugar vago. \n")

print(model.numero_lugaresK)
print(model.numero_lugaresJ)
print(model.numero_lugaresI)
print(model.numero_lugaresH)
print(model.numero_lugaresG)
print(model.numero_lugaresF)
print(model.numero_lugaresE)
print(model.numero_lugaresD)
print(model.numero_lugaresC)
print(model.numero_lugaresB)
print(model.numero_lugaresA)
print(model.Palco)

print("Insira os comandos RL(para reservar lugar), ER(para eliminar reserva), AR(alterar reserva) e CVB(para consultar o valor da bilheteira).")
def main ():
    valor_bilheteira = model.Valor_bilheteira
    while True:
        try:
            comandos = input().split(" ")
        except EOFError:
            return
    
        
        if comandos [0] == "RL": #RL -> reservar lugar na sala   
            letra = input("Digite a letra da fila desejada: ")
            numero = input("Digite o numero do lugar desejado: ")
            data = input("Insira a data do espetáculo desejada(dd/mm/aaaa): ")

            while controller.valido_letra(letra) == False:
                print("Letra da fila inválida.")
                letra = input("Digite a letra da fila desejada novamente: ")

            while controller.valido_numero(letra, numero) == False:
                print("Número do lugar inválido.")
                numero = input("Digite o número do lugar desejado novamente: ")
            
            while controller.Validar_data(data) == False:
                print("Data inválida.")
                data = input("Insira a data do espetáculo desejada novamente(dd/mm/aaaa): ")
            
            if controller.verificar_lugares_reservados(letra, numero, data) == True:
                controller.reservar_lugares(letra, numero, data)
                print("Lugar registado com sucesso.")
            else:
                print("Lugar já se encontra reservado, insira o comando (RL) para reservar lugar novamente.")
                
                

        if comandos[0] == "ER": #ER -> Eliminar reserva
            print("\n Escolha um lugar ocupado \n")
            letra = input("Digite a letra da fila desejada: ")
            numero = input("Digite o numero do lugar desejado: ")
            data = input("Insira a data do espetáculo desejada(dd/mm/aaaa): ")

            while controller.valido_letra(letra) == False:
                print("Letra da fila inválida.")
                letra = input("Digite a letra da fila desejada novamente: ")

            while controller.valido_numero(letra, numero) == False:
                print("Número do lugar inválido.")
                numero = input("Digite o número do lugar desejado novamente: ")

            while controller.Validar_data(data) == False:
                print("Data inválida.")
                data = input("Insira a data do espetáculo desejada novamente(dd/mm/aaaa): ")
            
                                                    
            if controller.verificar_lugares_reservados(letra, numero, data) == False:
                controller.eliminar_lugar_reservado(letra, numero, data)
                print("Lugar eliminado com sucesso.")
            else:
                print("Lugar não se encontra registado.")


        if comandos[0] == "AR": #AR -> Alterar reserva
            print(model.Lugares_reservados)
            lugar_a_alterar = input("Indique qual o lugar que pretende alterar: ")
            model.Lugares_reservados.remove(lugar_a_alterar)
            dado = input("O que pretende alterar na reserva? Escreva fila (para alterar a fila do lugar), número (para alterar o número do lugar), data (para alterar a data):  ")
            if dado == "fila":
                letra = input("Digite a letra da fila para qual quer alterar: ")
            elif dado == "número":
                numero = input("Digite o número do lugar para qual quer alterar: ")
            elif dado == "data":
                print(f"As datas dos espetáculos são:{model.Datas} \n")
                data == input("Digite a data para qual quer alterar a sua reserva(dd/mm/aaaa): ")

            if controller.verificar_lugares_reservados(letra, numero, data) == True:
                controller.reservar_lugares(letra, numero, data)
                print("Lugar registado com sucesso.")


        if comandos[0] == "CVB": #CVB -> Consultar valor da bilheteira
            print(f"As datas dos espetáculos são: {model.Datas}\n")
            datab = input("Digite a data que quer consultar o valor: ")
            if datab == "10" or datab == "12" or datab == "13" or datab == "27"or datab == "29":
                if datab in model.Dias:
                    print (model.data_reservada.count(datab))
                        

                
                

            elif datab == "mês":
                return
            elif datab == "ano":
                controller.contar_valor(datab)
                