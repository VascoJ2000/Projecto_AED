import model
import controller

def main ():
    valor_bilheteira = model.Valor_bilheteira
    while True:
        try:
            comandos = input().split(" ")
        except EOFError:
            return
    
    
        if comandos [0] == "RL": #RL -> reservar lugar na sala
            print(model.numero_lugaresK)
            print(model.numero_lugaresJ)
            print(model.numero_lugaresI)
            print(model.numero_lugaresH)
            print(model.numero_lugaresG)
            print(model.numero_lugaresF)
            print(model.numero_lugaresE)
            print(model.numero_lugaresD)
            print(model.numero_lugaresC)
            print(model.numero_lugaresB)
            print(model.numero_lugaresA)
            print(model.Palco)
        
            
            print("\n Escolha um lugar vago \n")
            print(f"As datas dos espetáculos são: {model.Datas}\n")
            letra = input("Digite a letra da fila desejada: ")
            numero = input("Digite o numero do lugar desejado: ")
            data = input("Insira a data do espetáculo desejada(dd/mm/aaaa): ")

            while controller.valido_letra(letra) == False:
                print("Letra da fila inválida.")
                letra = input("Digite a letra da fila desejada novamente: ")

            while controller.valido_numero(letra, numero) == False:
                print("Número do lugar inválido.")
                numero = input("Digite o número do lugar desejado novamente: ")
            
            while controller.Validar_data(data) == False:
                print("Data inválida.")
                data = input("Insira a data do espetáculo desejada novamente(dd/mm/aaaa): ")
            
            if controller.verificar_lugares_reservados(letra, numero, data) == True:
                controller.reservar_lugares(letra, numero, data)
                print("Lugar registado com sucesso.")
            else:
                print("Lugar já se encontra reservado, insira o comando (RL) para reservar lugar novamente.")
                
                

        if comandos[0] == "ER": #ER -> Eliminar reserva
           print()


        if comandos[0] == "AR": #AR -> Alterar reserva
          print()


        if comandos[0] == "CVB": #CVB -> Consultar valor da bilheteira
            print(*valor_bilheteira , sep = ' , ')
