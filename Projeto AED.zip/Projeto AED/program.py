import sys
import view

sys.stdout.reconfigure(encoding = "UtF-8")
if __name__ == '__main__':
    view.main()